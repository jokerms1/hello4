var loginPage = document.querySelector('#login-page'),
	usernameInput = document.querySelector('#username'),
	loginButton = document.querySelector('#login'),
	callPage = document.querySelector('#call-page'),
	theirUsernameInput = document.querySelector('#their-username'),
	callButton = document.querySelector('#call'),
	hangUpButton = document.querySelector('#hang-up');

	callPage.style.display = "none";
	//loginPage.style.display = "none";
var socket = io();

var name = "";
loginButton.addEventListener("click",function (event){
	name = usernameInput.value;
	if(name.length > 0){
		send({
			type:"login",
			name:name
		});
	}
});

socket.onmessage = function (message){
	console.log("Got message",message.data);
	var data = JSON.parse(message.data);

	switch(data.type){
		case "login":
			onLogin(data.success);
		break;
	}
}
socket.onerror = function(err){
	console.log("Got error",err);
};

function onLogin(success){
	if( success == false){
		alert("Login unsuccessful,please try a different name.");
	}else{
		loginPage.style.display = "none";
		callPage.style.display = "block";
	}
}
function send(message){
	if(connectedUser){
		message.name = connectedUser;
	}
	socket.send(JSON.stringify(message));
}
