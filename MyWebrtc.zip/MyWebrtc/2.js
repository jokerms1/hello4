var https = require('https');
var fs = require('fs');
var querystring = require("querystring");  
var postData = querystring.stringify({    
	'msg': 'Hello World!'
});  
var options = {    
	hostname: '127.0.0.1',    
	port: 9000,    
	path: '/',    
	method: 'POST',    
	requestCert:true,  
	//请求客户端证书    
	rejectUnauthorized: false, 
	//不拒绝不受信任的证书    
	headers: {        
		'Content-Type': 'application/x-www-form-urlencoded',        
		'Content-Length': Buffer.byteLength(postData)    
	}
};  
var req = https.request(options, (res)  =>{    
	console.log(`STATUS: ${res.statusCode}`);    
	console.log(`HEADERS: ${JSON.stringify(res.headers)}`);    
	res.setEncoding('utf8');    
	res.on('data', (chunk) =>{        
		console.log(`BODY: ${chunk}`);    
	});    
	res.on('end', ()=>{        
		console.log('No more data in response.');    
	});
});  
req.on('error', (e)=> {    
		console.error(`problem with request: ${e.message}`);
});  	
// write data to request body
req.write(postData);
req.end();

