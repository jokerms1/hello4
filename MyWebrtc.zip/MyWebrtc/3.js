const https = require('https');
const fs = require("fs");

const options = {
  key: fs.readFileSync('./2043129_huyuanrui.top.key'),
  cert: fs.readFileSync('./2043129_huyuanrui.top.pem')
};

https.createServer(options, (req, res) => {
  fs.readFile("./index.html",function(err,data){
			res.end(data);
  })
}).listen(2000);