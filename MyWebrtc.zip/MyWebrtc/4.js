const https = require('https');
const fs = require("fs");


const options = {
  key: fs.readFileSync('./2043129_huyuanrui.top.key'),
  cert: fs.readFileSync('./2043129_huyuanrui.top.pem')
};

var httpsServer = https.createServer(options,function(req,res){
	fs.readFile("./1.html",function(err,data){
			res.end(data);
  })
});
httpsServer.listen(2000);

var users ={},sd = {};
var io = require('socket.io')(httpsServer);
io.on("connection",function(socket){
	socket.on("message",function(message){
		try{
			data = JSON.parse(message);
		}catch(e){
			console.log("Error parsing JSON");
			data = {};
		}
		switch(data.type){
			case "login":
				console.log("User logged in as",data.name);
				if(users[data.name]){
					sendTo(socket,{
						type:"login",
						success:false
					});
				}else{
					users[data.name] = socket;
					sd[socket] = data.name 
					sendTo(socket,{
						type:"login",
						success:true
					});
				}
			break;
			case "offer":
				console.log("Sending offer to",data.name);
				var conn = users[data.name];
				if(conn != null)
				{
					socket.otherName = data.name;
					sendTo(conn,{
						type:"offer",
						offer:data.offer,
						name:sd[socket]
					});
				}
			break;
			case "answer":
				console.log("Sending answer to",data.name);
				var conn = users[data.name];
				if(conn != null){
					socket.othreName = data.name;
					sendTo(conn,{
						type:"answer",
						answer:data.answer
					});
				}
			break;
			case "candidate":
				console.log("Sending candidate to",data.name);
				var conn = users[data.name];
				if(conn != null){
					sendTo(conn,{
						type:"candidate",
						candidate:data.candidate
					});
				}
			break;
			case "leave":
				console.log("Disconnection user from", data.name);
				var conn = users[data.name];
				socket.othreName = null;
				if(conn != null){
					sendTo(conn,{
						type:"leave"
					});
				}
			break;
			default:
				sendTo(socket,{
					type:"error",
					message: "Unrecognized command : " + data.type
				});
			break;
		}
	});

	socket.on('close',function(){
		if(socket.name){
			delete users[socket.name];

			if(socket.otherName){
				console.log("Disconnection user from",socket.otherName);
				var conn = users[socket.otherName];
				conn.otherName = null;
				if(conn != null){
					sendTo(conn,{
						type:"leave"
					});
				}
			}
		}
	});
	function sendTo(conn,message){
		conn.send(JSON.stringify(message));
	}
});

