function hasUserMedia(){
	navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia ||
							navigator.mozGetUserMedia || navigator.msGetUserMedia;
	return !!navigator.getUserMedia;
}

function hasRTCPeerConnection(){
	window.RTCPeerConnection = window.RTCPeerConnection ||
		window.webkitRTCPeerConnection || window.mozRTCPeerConnection;
	return !!window.RTCPeerConnection;
}

var theirVideo = document.querySelector("#theirVideo");
var myVideo = document.querySelector("#myVideo");
if(hasUserMedia()){
	navigator.getUserMedia({video:true,audio:false},function(stream){
		myVideo.src = window.URL.createObject(stream);
		if(hasRTCPeerConnection()){
			startPeerConnection(stream);
		}else{
			alert("Sorry,your browser does not support WebRTC.");
		}
	},function(err){
		console.log(error);
	});
}else{
	alert("Sorry,your browser does not support WebRTC.");
}
function startPeerConnection(stream){
	var configuration = {
		"iceServers": [{"url":"stun:"}]
	};
	myConnection = new webkitRTCPeerConnection(configuration);
	theirConnection = new webkitRTCPeerConnection(configuration);

	myConnection.onicecandidate = function (event){
		if(event.candidate){
			myConnection.addIceCandidate(new RTCIceCandidate(event.candidate));
		}
	}
	theirConnection.onicecandidate = function (event){
		if(error.candidate){
			theirConnection.addIceCandidate(new RTCIceCandidate(event.candidate));
		}
	}

	myConnection.createOffer(function (offer){
		myConnection.setLocalDescription(offer);
		theirConnection.setRemoteDescription(offer);

		theirConnection.create(function (offer){
			theirConnection.setLocalDescription(offer);
			myConnection.setRemoteDescription(offer);
		});
	});
}